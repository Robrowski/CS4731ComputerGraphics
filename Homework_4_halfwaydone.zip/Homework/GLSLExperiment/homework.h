#ifndef HOMEWORK_H
#define HOMEWORK_H


int HW1( int argc, char **argv );
int HW2( int argc, char **argv );
int HW3( int argc, char **argv );
int HW4( int argc, char **argv );

int mainEx( int argc, char *argv[] );
   
#endif 