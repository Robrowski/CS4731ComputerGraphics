#include "homework.h"
#include <stdio.h>

// THE MAIN FUNCTION
int main( int argc, char **argv )
{
	printf("Poop");
	
	//HW1( argc, argv );
	HW2( argc, argv );


	while(1); // keep the program running
}

