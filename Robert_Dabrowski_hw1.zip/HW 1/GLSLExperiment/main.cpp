#include "homework.h"


// THE MAIN FUNCTION
int main( int argc, char **argv )
{
	HW1( argc, argv );
}